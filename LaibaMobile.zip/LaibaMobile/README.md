# 🤖 Laiba AI - Android Assistant

## Kya hai ye app?
Laiba ek Android AI assistant hai jo:
- 🎙️ **"Hey Laiba"** bolne par automatically activate hoti hai
- 💬 Tumse Hinglish mein baat karti hai
- 📱 Phone ko voice se control karti hai
- 🔵 Home screen pe **floating bubble** rehta hai hamesha
- 🔴 Notification se band kar sakte ho

---

## ⚙️ Setup Kaise Karo

### Step 1 — API Keys daalo
`LaibaBrain.kt` file mein apni keys daalo:
```kotlin
private const val GEMINI_API_KEY = "YAHAN_APNI_GEMINI_KEY_DAALO"
private const val GROQ_API_KEY   = "YAHAN_APNI_GROQ_KEY_DAALO"
```

**Keys kahan se milegi?**
- Gemini: https://aistudio.google.com/app/apikey (FREE)
- Groq: https://console.groq.com (FREE)

---

### Step 2 — Android Studio mein open karo
1. Android Studio install karo
2. `Open Project` → ye folder select karo
3. Gradle sync hone do

---

### Step 3 — Phone pe install karo
1. Phone mein **Developer Options** on karo
2. **USB Debugging** on karo
3. Phone connect karo
4. `Run ▶️` press karo

---

## 📱 Pehli baar use karne par

App open hogi aur ye permissions maangi:
- ✅ **Overlay permission** — floating bubble ke liye (MUST)
- ✅ **Microphone** — voice ke liye (MUST)
- ✅ **Battery optimization** — hamesha active rehne ke liye

---

## 🎮 Voice Commands

| Tum bolte ho | Laiba kya karti hai |
|---|---|
| `Hey Laiba` | Activate hoti hai |
| `WhatsApp kholo` | WhatsApp open |
| `Camera kholo` | Camera open |
| `Alarm lagao 7 baje` | 7am alarm set |
| `Volume badha` | Volume up |
| `Torch on karo` | Flashlight on |
| `Mujhe naya bata` | Baat karti hai |

---

## 🔴 Band Kaise Karo
- Notification mein **"Stop Laiba"** tap karo

## 🔵 Dobara Start Kaise Karo
- App icon tap karo home screen pe

---

## 📁 Project Structure
```
app/src/main/
├── kotlin/com/laiba/assistant/
│   ├── MainActivity.kt          ← App entry point
│   ├── ai/LaibaBrain.kt         ← Gemini + Groq AI
│   ├── services/
│   │   ├── FloatingBubbleService.kt  ← Floating icon
│   │   └── WakeWordService.kt        ← "Hey Laiba" listener
│   ├── ui/LaibaOverlayActivity.kt    ← Chat UI
│   └── utils/
│       ├── PhoneController.kt        ← Phone commands
│       └── BootReceiver.kt           ← Auto-start on boot
└── res/
    ├── layout/                  ← UI layouts
    ├── drawable/                ← Icons & shapes
    └── values/                  ← Colors, strings, themes
```

---

Made with ❤️ — Laiba AI Assistant
