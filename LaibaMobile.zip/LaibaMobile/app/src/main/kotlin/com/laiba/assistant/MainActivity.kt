package com.laiba.assistant

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import com.laiba.assistant.services.FloatingBubbleService
import com.laiba.assistant.services.WakeWordService

class MainActivity : AppCompatActivity() {

    private val overlayPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) {
        if (Settings.canDrawOverlays(this)) {
            startLaibaServices()
        } else {
            Toast.makeText(this, "Overlay permission required for floating bubble!", Toast.LENGTH_LONG).show()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        checkPermissionsAndStart()
    }

    private fun checkPermissionsAndStart() {
        if (!Settings.canDrawOverlays(this)) {
            val intent = Intent(
                Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:$packageName")
            )
            overlayPermissionLauncher.launch(intent)
        } else {
            startLaibaServices()
        }
    }

    private fun startLaibaServices() {
        // Start floating bubble
        val bubbleIntent = Intent(this, FloatingBubbleService::class.java)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            startForegroundService(bubbleIntent)
        } else {
            startService(bubbleIntent)
        }

        // Start wake word listener
        val wakeIntent = Intent(this, WakeWordService::class.java)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            startForegroundService(wakeIntent)
        } else {
            startService(wakeIntent)
        }

        Toast.makeText(this, "Laiba is now active! Say 'Hey Laiba'", Toast.LENGTH_SHORT).show()
        finish() // Close app — bubble stays on screen
    }
}
