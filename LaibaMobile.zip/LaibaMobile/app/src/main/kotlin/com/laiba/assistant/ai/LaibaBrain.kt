package com.laiba.assistant.ai

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.OutputStreamWriter
import java.net.HttpURLConnection
import java.net.URL

data class Message(val role: String, val content: String)

object LaibaBrain {

    // ⚠️ Replace these with your actual API keys
    private const val GEMINI_API_KEY = "YOUR_GEMINI_API_KEY"
    private const val GROQ_API_KEY = "YOUR_GROQ_API_KEY"

    private val conversationHistory = mutableListOf<Message>()

    private val systemPrompt = """
        You are Laiba, a friendly and intelligent AI voice assistant living on the user's Android phone.
        
        Your personality:
        - Warm, helpful, and conversational in Hinglish (Hindi + English mix)
        - You call the user "bhai" or by their name if they tell you
        - You give SHORT, crisp voice-friendly answers (max 2-3 sentences unless asked for detail)
        - You can control their phone when they ask: open apps, make calls, set alarms, send messages
        - You are always active and ready
        
        Phone control commands you understand:
        - "open [app name]" → respond with ACTION:OPEN_APP:[package]
        - "call [contact]" → respond with ACTION:CALL:[name]  
        - "set alarm [time]" → respond with ACTION:SET_ALARM:[time]
        - "send message to [contact] [message]" → respond with ACTION:SEND_SMS:[contact]:[message]
        - "play [song/music]" → respond with ACTION:PLAY_MUSIC:[query]
        - "take screenshot" → respond with ACTION:SCREENSHOT
        - "what time is it" → respond with ACTION:GET_TIME
        - "open settings" → respond with ACTION:OPEN_APP:com.android.settings
        - "increase volume" → respond with ACTION:VOLUME_UP
        - "decrease volume" → respond with ACTION:VOLUME_DOWN
        - "torch on/off" → respond with ACTION:TORCH:[on/off]
        
        If no action is needed, just reply naturally in 1-3 sentences.
        Always be warm and friendly!
    """.trimIndent()

    suspend fun chat(userMessage: String): String {
        conversationHistory.add(Message("user", userMessage))

        return try {
            // Try Gemini first, fallback to Groq
            val response = try {
                askGemini(userMessage)
            } catch (e: Exception) {
                askGroq()
            }
            conversationHistory.add(Message("assistant", response))
            response
        } catch (e: Exception) {
            "Kuch problem ho gayi bhai, dobara try karo!"
        }
    }

    private suspend fun askGemini(userMessage: String): String = withContext(Dispatchers.IO) {
        val url = URL("https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key=$GEMINI_API_KEY")
        val connection = url.openConnection() as HttpURLConnection

        connection.apply {
            requestMethod = "POST"
            setRequestProperty("Content-Type", "application/json")
            doOutput = true
            connectTimeout = 10000
            readTimeout = 15000
        }

        // Build conversation for Gemini
        val contents = JSONArray()

        // Add system prompt as first user message
        val systemContent = JSONObject().apply {
            put("role", "user")
            put("parts", JSONArray().put(JSONObject().put("text", systemPrompt)))
        }
        val systemReply = JSONObject().apply {
            put("role", "model")
            put("parts", JSONArray().put(JSONObject().put("text", "Samajh gaya! Main Laiba hoon, ready hoon!")))
        }
        contents.put(systemContent)
        contents.put(systemReply)

        // Add conversation history (last 10 messages)
        val recent = conversationHistory.takeLast(10)
        recent.forEach { msg ->
            val role = if (msg.role == "user") "user" else "model"
            val content = JSONObject().apply {
                put("role", role)
                put("parts", JSONArray().put(JSONObject().put("text", msg.content)))
            }
            contents.put(content)
        }

        val body = JSONObject().apply {
            put("contents", contents)
            put("generationConfig", JSONObject().apply {
                put("temperature", 0.8)
                put("maxOutputTokens", 200)
            })
        }

        OutputStreamWriter(connection.outputStream).use { it.write(body.toString()) }

        val response = connection.inputStream.bufferedReader().readText()
        val json = JSONObject(response)
        json.getJSONArray("candidates")
            .getJSONObject(0)
            .getJSONObject("content")
            .getJSONArray("parts")
            .getJSONObject(0)
            .getString("text")
    }

    private suspend fun askGroq(): String = withContext(Dispatchers.IO) {
        val url = URL("https://api.groq.com/openai/v1/chat/completions")
        val connection = url.openConnection() as HttpURLConnection

        connection.apply {
            requestMethod = "POST"
            setRequestProperty("Content-Type", "application/json")
            setRequestProperty("Authorization", "Bearer $GROQ_API_KEY")
            doOutput = true
            connectTimeout = 10000
            readTimeout = 15000
        }

        val messages = JSONArray()

        // System message
        messages.put(JSONObject().apply {
            put("role", "system")
            put("content", systemPrompt)
        })

        // Conversation history (last 10)
        conversationHistory.takeLast(10).forEach { msg ->
            messages.put(JSONObject().apply {
                put("role", msg.role)
                put("content", msg.content)
            })
        }

        val body = JSONObject().apply {
            put("model", "llama-3.1-8b-instant")
            put("messages", messages)
            put("max_tokens", 200)
            put("temperature", 0.8)
        }

        OutputStreamWriter(connection.outputStream).use { it.write(body.toString()) }

        val response = connection.inputStream.bufferedReader().readText()
        val json = JSONObject(response)
        json.getJSONArray("choices")
            .getJSONObject(0)
            .getJSONObject("message")
            .getString("content")
    }

    fun clearHistory() {
        conversationHistory.clear()
    }
}
