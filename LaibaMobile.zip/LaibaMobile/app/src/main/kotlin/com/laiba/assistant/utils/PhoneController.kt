package com.laiba.assistant.utils

import android.content.Context
import android.content.Intent
import android.media.AudioManager
import android.net.Uri
import android.os.Build
import android.provider.AlarmClock
import android.provider.Settings
import android.telephony.SmsManager
import android.hardware.camera2.CameraManager
import android.hardware.camera2.CameraCharacteristics

object PhoneController {

    data class ActionResult(val executed: Boolean, val voiceResponse: String)

    fun parseAndExecute(context: Context, aiResponse: String): ActionResult {
        // Check if AI returned an action command
        if (!aiResponse.contains("ACTION:")) {
            return ActionResult(false, aiResponse) // Just a normal text reply
        }

        val actionLine = aiResponse.lines().find { it.contains("ACTION:") } ?: return ActionResult(false, aiResponse)
        val parts = actionLine.trim().split(":")

        return when {
            actionLine.contains("ACTION:OPEN_APP") -> {
                val packageName = parts.getOrNull(2) ?: return ActionResult(false, "App nahi mila!")
                openApp(context, packageName)
            }
            actionLine.contains("ACTION:CALL") -> {
                val contact = parts.getOrNull(2) ?: return ActionResult(false, "Contact nahi mila!")
                makeCall(context, contact)
            }
            actionLine.contains("ACTION:SET_ALARM") -> {
                val timeStr = parts.getOrNull(2) ?: return ActionResult(false, "Time nahi mila!")
                setAlarm(context, timeStr)
            }
            actionLine.contains("ACTION:SEND_SMS") -> {
                val contact = parts.getOrNull(2) ?: ""
                val message = parts.drop(3).joinToString(":")
                sendSMS(context, contact, message)
            }
            actionLine.contains("ACTION:PLAY_MUSIC") -> {
                val query = parts.drop(2).joinToString(":")
                playMusic(context, query)
            }
            actionLine.contains("ACTION:SCREENSHOT") -> {
                ActionResult(true, "Screenshot feature ke liye accessibility service enable karo settings mein!")
            }
            actionLine.contains("ACTION:GET_TIME") -> {
                val time = java.text.SimpleDateFormat("hh:mm a", java.util.Locale.getDefault())
                    .format(java.util.Date())
                ActionResult(true, "Abhi $time baj rahe hain!")
            }
            actionLine.contains("ACTION:VOLUME_UP") -> {
                changeVolume(context, true)
            }
            actionLine.contains("ACTION:VOLUME_DOWN") -> {
                changeVolume(context, false)
            }
            actionLine.contains("ACTION:TORCH") -> {
                val on = parts.getOrNull(2)?.lowercase() == "on"
                toggleTorch(context, on)
            }
            else -> ActionResult(false, aiResponse)
        }
    }

    private fun openApp(context: Context, packageName: String): ActionResult {
        return try {
            val intent = context.packageManager.getLaunchIntentForPackage(packageName)
                ?: return ActionResult(false, "Yeh app install nahi hai!")
            intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK
            context.startActivity(intent)
            ActionResult(true, "App khol diya!")
        } catch (e: Exception) {
            ActionResult(false, "App nahi khul raha, check karo!")
        }
    }

    private fun makeCall(context: Context, contact: String): ActionResult {
        return try {
            val intent = Intent(Intent.ACTION_DIAL).apply {
                data = Uri.parse("tel:$contact")
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
            context.startActivity(intent)
            ActionResult(true, "$contact ko call kar raha hoon!")
        } catch (e: Exception) {
            ActionResult(false, "Call nahi ho raha!")
        }
    }

    private fun setAlarm(context: Context, timeStr: String): ActionResult {
        return try {
            // Parse time like "7:30" or "730" or "7 30"
            val cleaned = timeStr.replace(" ", ":").replace(".", ":")
            val timeParts = cleaned.split(":")
            val hour = timeParts.getOrNull(0)?.trim()?.toIntOrNull() ?: 7
            val minute = timeParts.getOrNull(1)?.trim()?.toIntOrNull() ?: 0

            val intent = Intent(AlarmClock.ACTION_SET_ALARM).apply {
                putExtra(AlarmClock.EXTRA_HOUR, hour)
                putExtra(AlarmClock.EXTRA_MINUTES, minute)
                putExtra(AlarmClock.EXTRA_MESSAGE, "Laiba Alarm")
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
            context.startActivity(intent)
            ActionResult(true, "$hour:${minute.toString().padStart(2,'0')} ka alarm set kar diya!")
        } catch (e: Exception) {
            ActionResult(false, "Alarm nahi set hua!")
        }
    }

    private fun sendSMS(context: Context, contact: String, message: String): ActionResult {
        return try {
            val intent = Intent(Intent.ACTION_SENDTO).apply {
                data = Uri.parse("smsto:$contact")
                putExtra("sms_body", message)
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
            context.startActivity(intent)
            ActionResult(true, "Message ready hai, bhej do!")
        } catch (e: Exception) {
            ActionResult(false, "Message nahi hua!")
        }
    }

    private fun playMusic(context: Context, query: String): ActionResult {
        return try {
            val intent = Intent(Intent.ACTION_VIEW).apply {
                data = Uri.parse("https://open.spotify.com/search/$query")
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
            context.startActivity(intent)
            ActionResult(true, "$query play kar raha hoon!")
        } catch (e: Exception) {
            ActionResult(false, "Music nahi chala!")
        }
    }

    private fun changeVolume(context: Context, up: Boolean): ActionResult {
        val audio = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        val direction = if (up) AudioManager.ADJUST_RAISE else AudioManager.ADJUST_LOWER
        audio.adjustStreamVolume(AudioManager.STREAM_MUSIC, direction, AudioManager.FLAG_SHOW_UI)
        return ActionResult(true, if (up) "Volume badha diya!" else "Volume kam kar diya!")
    }

    private fun toggleTorch(context: Context, on: Boolean): ActionResult {
        return try {
            val cameraManager = context.getSystemService(Context.CAMERA_SERVICE) as CameraManager
            val cameraId = cameraManager.cameraIdList.firstOrNull { id ->
                cameraManager.getCameraCharacteristics(id)
                    .get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
            } ?: return ActionResult(false, "Torch nahi mili!")

            cameraManager.setTorchMode(cameraId, on)
            ActionResult(true, if (on) "Torch on kar diya!" else "Torch off kar diya!")
        } catch (e: Exception) {
            ActionResult(false, "Torch control nahi hua!")
        }
    }
}
