package com.laiba.assistant.services

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.os.IBinder
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import androidx.core.app.NotificationCompat
import com.laiba.assistant.R
import com.laiba.assistant.ui.LaibaOverlayActivity

class WakeWordService : Service() {

    private var speechRecognizer: SpeechRecognizer? = null
    private var isListening = false

    companion object {
        const val CHANNEL_ID = "laiba_wake_channel"
        const val NOTIFICATION_ID = 2
        val WAKE_WORDS = listOf("hey laiba", "laiba", "hey laiba", "hy laiba", "hi laiba")
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
        startForeground(NOTIFICATION_ID, buildNotification())
        startListening()
    }

    private fun startListening() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) return

        speechRecognizer = SpeechRecognizer.createSpeechRecognizer(this)
        speechRecognizer?.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) { isListening = true }
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {}

            override fun onResults(results: Bundle?) {
                val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                matches?.forEach { result ->
                    val lower = result.lowercase().trim()
                    if (WAKE_WORDS.any { lower.contains(it) }) {
                        // Wake word detected! Open Laiba
                        activateLaiba()
                        return
                    }
                }
                // Keep listening
                restartListening()
            }

            override fun onError(error: Int) {
                isListening = false
                // Restart after short delay
                android.os.Handler(mainLooper).postDelayed({
                    restartListening()
                }, 1000)
            }

            override fun onPartialResults(partialResults: Bundle?) {
                // Check partial results too for faster response
                val partial = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                partial?.forEach { result ->
                    val lower = result.lowercase().trim()
                    if (WAKE_WORDS.any { lower.contains(it) }) {
                        activateLaiba()
                        return
                    }
                }
            }

            override fun onEvent(eventType: Int, params: Bundle?) {}
        })

        restartListening()
    }

    private fun restartListening() {
        speechRecognizer?.cancel()
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "en-IN") // Indian English
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
            putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 1500)
            putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_POSSIBLY_COMPLETE_SILENCE_LENGTH_MILLIS, 1500)
        }
        try {
            speechRecognizer?.startListening(intent)
        } catch (e: Exception) {
            android.os.Handler(mainLooper).postDelayed({ restartListening() }, 2000)
        }
    }

    private fun activateLaiba() {
        speechRecognizer?.cancel()
        val intent = Intent(this, LaibaOverlayActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP
            putExtra("FROM_WAKE_WORD", true)
        }
        startActivity(intent)

        // Restart listening after delay
        android.os.Handler(mainLooper).postDelayed({
            restartListening()
        }, 3000)
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Laiba Wake Word",
                NotificationManager.IMPORTANCE_MIN
            ).apply {
                description = "Always listening for Hey Laiba"
                setShowBadge(false)
            }
            val manager = getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(channel)
        }
    }

    private fun buildNotification(): Notification {
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("Listening for 'Hey Laiba'")
            .setContentText("Laiba wake word detector is active")
            .setSmallIcon(R.drawable.ic_laiba_notif)
            .setPriority(NotificationCompat.PRIORITY_MIN)
            .setOngoing(true)
            .build()
    }

    override fun onDestroy() {
        super.onDestroy()
        speechRecognizer?.destroy()
        isListening = false
    }
}
