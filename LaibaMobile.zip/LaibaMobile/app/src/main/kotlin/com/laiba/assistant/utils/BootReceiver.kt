package com.laiba.assistant.utils

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import com.laiba.assistant.services.FloatingBubbleService
import com.laiba.assistant.services.WakeWordService

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == Intent.ACTION_BOOT_COMPLETED ||
            intent.action == "android.intent.action.QUICKBOOT_POWERON") {

            // Auto-start Laiba on phone boot
            val bubbleIntent = Intent(context, FloatingBubbleService::class.java)
            val wakeIntent = Intent(context, WakeWordService::class.java)

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(bubbleIntent)
                context.startForegroundService(wakeIntent)
            } else {
                context.startService(bubbleIntent)
                context.startService(wakeIntent)
            }
        }
    }
}
