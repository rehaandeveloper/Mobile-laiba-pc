package com.laiba.assistant.ui

import android.content.Intent
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.view.View
import android.view.WindowManager
import android.widget.ImageButton
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.laiba.assistant.R
import com.laiba.assistant.ai.LaibaBrain
import com.laiba.assistant.utils.PhoneController
import kotlinx.coroutines.launch
import java.util.Locale

class LaibaOverlayActivity : AppCompatActivity(), TextToSpeech.OnInitListener {

    private lateinit var tts: TextToSpeech
    private lateinit var speechRecognizer: SpeechRecognizer
    private lateinit var tvStatus: TextView
    private lateinit var tvChat: TextView
    private lateinit var btnMic: ImageButton
    private lateinit var btnClose: ImageButton
    private lateinit var scrollView: ScrollView
    private lateinit var thinkingIndicator: LinearLayout

    private var isListening = false
    private var isTtsReady = false
    private val chatLog = StringBuilder()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Make it overlay-style
        window.apply {
            setFlags(
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
            )
            addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS)
            statusBarColor = android.graphics.Color.TRANSPARENT
        }

        setContentView(R.layout.activity_laiba_overlay)

        initViews()
        initTTS()
        initSpeechRecognizer()

        // Auto-start listening if woken by wake word
        val fromWakeWord = intent.getBooleanExtra("FROM_WAKE_WORD", false)
        if (fromWakeWord) {
            android.os.Handler(mainLooper).postDelayed({
                speak("Haan bolo, main sun rahi hoon!") {
                    startListening()
                }
            }, 500)
        } else {
            speak("Haan bolo!")
        }
    }

    private fun initViews() {
        tvStatus = findViewById(R.id.tvStatus)
        tvChat = findViewById(R.id.tvChat)
        btnMic = findViewById(R.id.btnMic)
        btnClose = findViewById(R.id.btnClose)
        scrollView = findViewById(R.id.scrollView)
        thinkingIndicator = findViewById(R.id.thinkingIndicator)

        btnMic.setOnClickListener {
            if (isListening) stopListening() else startListening()
        }

        btnClose.setOnClickListener {
            finish()
        }
    }

    private fun initTTS() {
        tts = TextToSpeech(this, this)
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            tts.language = Locale("hi", "IN") // Hindi Indian
            tts.setSpeechRate(0.95f)
            tts.setPitch(1.1f)
            isTtsReady = true
        }
    }

    private fun speak(text: String, onDone: (() -> Unit)? = null) {
        if (!isTtsReady) return
        tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "laiba_utterance")
        if (onDone != null) {
            android.os.Handler(mainLooper).postDelayed({
                onDone()
            }, (text.length * 60).toLong().coerceAtLeast(800))
        }
    }

    private fun initSpeechRecognizer() {
        speechRecognizer = SpeechRecognizer.createSpeechRecognizer(this)
        speechRecognizer.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) {
                isListening = true
                tvStatus.text = "Sun rahi hoon... 🎙️"
                btnMic.setImageResource(R.drawable.ic_mic_active)
            }
            override fun onBeginningOfSpeech() {
                tvStatus.text = "Bol raha hai... 🗣️"
            }
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {
                isListening = false
                tvStatus.text = "Soch rahi hoon... 🤔"
                btnMic.setImageResource(R.drawable.ic_mic_idle)
            }
            override fun onResults(results: Bundle?) {
                val text = results
                    ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                    ?.firstOrNull() ?: return
                handleUserInput(text)
            }
            override fun onError(error: Int) {
                isListening = false
                tvStatus.text = "Tap karo bolne ke liye 🎤"
                btnMic.setImageResource(R.drawable.ic_mic_idle)
            }
            override fun onPartialResults(partialResults: Bundle?) {
                val partial = partialResults
                    ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                    ?.firstOrNull()
                if (!partial.isNullOrEmpty()) tvStatus.text = "\"$partial\""
            }
            override fun onEvent(eventType: Int, params: Bundle?) {}
        })
    }

    private fun startListening() {
        if (isListening) return
        tts.stop()
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN")
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "hi-IN,en-IN")
            putExtra(RecognizerIntent.EXTRA_ONLY_RETURN_LANGUAGE_PREFERENCE, false)
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
        }
        speechRecognizer.startListening(intent)
        btnMic.setImageResource(R.drawable.ic_mic_active)
    }

    private fun stopListening() {
        speechRecognizer.stopListening()
        isListening = false
        btnMic.setImageResource(R.drawable.ic_mic_idle)
    }

    private fun handleUserInput(userText: String) {
        // Add to chat log
        chatLog.appendLine("Tum: $userText")
        updateChatUI()

        // Show thinking
        thinkingIndicator.visibility = View.VISIBLE
        tvStatus.text = "Soch rahi hoon... 🧠"

        lifecycleScope.launch {
            val aiResponse = LaibaBrain.chat(userText)

            // Check for phone actions
            val result = PhoneController.parseAndExecute(this@LaibaOverlayActivity, aiResponse)

            val displayText = if (result.executed) result.voiceResponse else aiResponse
            val speakText = result.voiceResponse

            runOnUiThread {
                thinkingIndicator.visibility = View.GONE
                chatLog.appendLine("Laiba: $displayText\n")
                updateChatUI()
                tvStatus.text = "Tap karo bolne ke liye 🎤"
                speak(speakText)
            }
        }
    }

    private fun updateChatUI() {
        tvChat.text = chatLog.toString()
        scrollView.post { scrollView.fullScroll(ScrollView.FOCUS_DOWN) }
    }

    override fun onDestroy() {
        super.onDestroy()
        tts.stop()
        tts.shutdown()
        speechRecognizer.destroy()
    }

    override fun onBackPressed() {
        finish()
    }
}
